//
//  DeailView.swift
//  H4X0R News
//
//  Created by William Huang on 2023/8/9.
//

import SwiftUI
import WebKit

struct DeailView: View {
    
    let url: String?
    
    var body: some View {
        WebView(urlString: url)
    }
}

struct DeailView_Previews: PreviewProvider {
    static var previews: some View {
        DeailView(url: "https://www.google.com")
    }
}
