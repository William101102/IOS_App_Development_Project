//
//  ContentView.swift
//  H4X0R News
//
//  Created by William Huang on 2023/8/9.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var networkManager = NetworkManager()
    
    var body: some View {
        NavigationView{
            List(networkManager.posts){
                post in
                NavigationLink(destination: DeailView(url: post.url)) {
                    HStack {
                        Text(String(post.points))
                        Text(post.title)
                    }
                }
            }
            .navigationBarTitle("H4X0R News")
        }
        .onAppear {
            self.networkManager.fetchData()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




//let posts = [
//    Post(id: "1" , title: "Hello"),
//    Post(id: "2" , title: "Hello1"),
//    Post(id: "3" , title: "Hello2")
//]
