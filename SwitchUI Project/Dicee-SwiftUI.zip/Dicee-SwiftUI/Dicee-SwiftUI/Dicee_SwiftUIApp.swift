//
//  Dicee_SwiftUIApp.swift
//  Dicee-SwiftUI
//
//  Created by William Huang on 2023/8/9.
//

import SwiftUI

@main
struct Dicee_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
