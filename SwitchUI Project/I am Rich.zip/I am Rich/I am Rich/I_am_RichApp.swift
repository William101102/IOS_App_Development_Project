//
//  I_am_RichApp.swift
//  I am Rich
//
//  Created by William Huang on 2023/8/9.
//

import SwiftUI

@main
struct I_am_RichApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
